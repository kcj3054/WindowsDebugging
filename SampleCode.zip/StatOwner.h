#pragma once
class StatOwner
{

};

