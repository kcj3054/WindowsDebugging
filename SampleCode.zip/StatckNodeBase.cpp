#include "StatckNodeBase.h"

StatckNodeBase::StatckNodeBase(StatType statType, StatVisibility statVisibility, std::initializer_list<StatType>&& dependencySet)
{

}
