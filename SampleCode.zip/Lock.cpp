#include "Lock.h"

void Lock::ReadLock()
{

}
