#pragma once
class StatNodeBase
{

};

