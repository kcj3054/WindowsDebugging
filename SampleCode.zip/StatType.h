#pragma once

enum class StatType : int
{
	MIN = 0,
	HP = 1,
	MP = 2,
	MAX = 200
};

enum class StatVisibility : int
{
	MIN = 0,
	STAT_VISIBILITY_OTHER = 1,
	MAX = 200
};

enum class StatValue : int
{
	MIN = 0,

	MAX = 200
};